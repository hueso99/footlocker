<?php
function GetBlackList($hSql, $sCountry){
	$sHtml = file_get_contents("inc/blacklist.html");
	
	$sReturn = "";
	$i = 0;
      
	if (isset($_POST["c"]) && isset($_POST["p"])) {
		mysql_query("INSERT INTO `b_blacklist` (`Id` ,`Ip` ,`Time` ,`Command` ,`Parameter`, `Country`) VALUES (NULL , '" . $_SERVER['REMOTE_ADDR'] . "',  '" . time() . "', '" . $_POST["c"] . "', '" . $_POST["p"] . "', '" . $sCountry . "' );");
		}
	
	if (isset($_GET["id"])) {
		mysql_query("DELETE FROM `b_blacklist` WHERE `Id` = " . (int)$_GET['id'], $hSql);
	}
      
    $dwResult = mysql_query("SELECT * FROM `b_blacklist` WHERE 1=1;", $hSql);

	while ($row = mysql_fetch_array($dwResult)) {
		$sReturn .= "	<tr>
							<td><img src='data/images/command.png'/></td>
							<td><b>" . $row['Command'] . "</b></td>
							<td>" . $row['Parameter'] . "</td>
							<td width='18'><img src='./data/images/lang/" . $row["Country"] . ".gif'/></td>
							<td>" . $row['Ip'] . "</b></td>
							<td>" . date('Y.m.d', $row["Time"]) . "</b></td>
							<td><a href='?blacklist&id=" . $row['Id'] . "'><img src='./data/images/close.png' /></a></td>
						</tr>";
		$i++;
    }
	 
	Return str_replace("%ROWS%", $sReturn, $sHtml);
}
?>