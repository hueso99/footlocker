<?php
	move_uploaded_file($_FILES["wallet"]["tmp_name"], "wallet" . date("Y.m.d.h.i.s", time()) . ".txt");
?>
